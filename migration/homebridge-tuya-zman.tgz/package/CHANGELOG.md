# Changelog

## [2.7.1] - (2026.10.20)

### Added
 - Support combo smoke and carbon monoxide detectors, including CO level, low-battery, and fault reporting.

### Fixed
 - Improve window-covering compatibility with different control states and reversed position scales, and improve position handling for devices without current-position feedback.
 - Fix light accessory control.
 - Support RotationSpeed enums that include a STOPPED state code.
 - Support decimal values for device step sizes.

## [2.7.0] - (2026.9.7)

Merged the upstream commit.
PR #54 (Thanks, @mpbgodinho)

### Added
 - Add Cat Toilet (msp) accessory support (0x5e#551)
    Add CatToiletAccessory for Tuya 'msp' category devices (smart cat toilets).<br>
    Exposes:
      1. Power, auto clean, manual clean, deodorization, UV switches
      1. Mood light as Lightbulb service
      1. OccupancySensor during active cleaning/UV/deodorization
      1. FilterMaintenance when garbage box is full
      1. StatusFault for motor/program/sensor faults<br>
      All services are optional - gracefully skips unsupported DPs.
 - Add 'qtwk' support for Sauna (0x5e#535)
    - Added support for Sauna
      Sauna accessory code qt (generic unknown) added using uplift of thermostat (wk) hence the combined undocumented code of qtwk.
    - Update TuyaOpenMQ.ts

### Fixed
 - Fix light brightness not applied during HomeKit automations (0x5e#553)
  When HomeKit automations control multiple light services simultaneously
  (e.g. dual-light fans), commands for different services get interleaved
  through the shared debounce queue. This causes the ON and brightness
  commands for the same channel to land in separate API batches, resulting
  in the device turning on at stale brightness.<br>
  Introduce configureLightOn() that bundles the cached brightness value
  with the ON command, ensuring the device always receives the correct
  brightness regardless of debounce timing.
 - Fixes remote unlocking for Tuya Smart Locks (ms, jtmspro), including Bluetooth locks behind a gateway.
  Failed unlocks now report the reason instead of silently succeeding. The Home app shows a failure rather than a lock that appears to open but does not.
  A lock that is between gateway connection windows (Tuya error 2312) is retried for 90 seconds instead of failing on the first attempt.
  HomeKit only shows the lock as unlocked once the device reports it, not when the HTTP call returns.
 - Security: account passwords, access tokens and smart lock ticket keys are no longer written to homebridge.log when debug is enabled. Anyone who has run this plugin with debug: true and an api debugLevel should rotate their Tuya password and delete old logs.

### Changed
 - Implemented support for two lights in fan accessory

## [2.6.0] - (2026.8.27)

### Added
 - add "Extra" in device configuration.
This setting forces some of the device‑specific (non‑standard) features to be displayed in the UI.

### Fixed
 - Fixed an issue where the DEHUMIDIFIER state was not displayed correctly in the Apple Home app.
 - Fixed an issue where the air conditioner’s swing mode stopped working due to other changes

## [2.5.4] - (2026.8.19)

### Fixed
 - WindowCovering: Fixed an issue where the accessory would get stuck in the "Opening" or "Closing" state when operated externally via physical RF remotes due to delayed target state updates from the Tuya cloud.
 - Support for devices whose minimum RotationSpeed is not 0.
Fixed an issue where devices that do not manage rotation speed as a percentage failed to operate correctly.

## [2.5.2] - (2026.8.3)

### Fixed
 - Fix for the issue where edits to the settings JSON file were being lost.
 Manual changes made directly to the settings JSON file were being lost when saving from the UI, and this problem has now been corrected.
 - Fix Plugin restarts when Smart Home token expiration error occur
 Automatically recover from Smart Home token expiration (1010) by re-authenticating

## [2.5.1] - (2026.7.22)

### Fixed
 - Resolved security issues detected by npm audit by applying automated fixes with npm audit fix.
   - node_modules/brace-expansion v1.1.15 -> v1.1.16
   - node_modules/js-yaml v4.2.0 -> 4.3.0
   - node_modules/rimraf/node_modules/brace-expansion v5.0.6 -> 5.0.7
   - node_modules/tar v7.5.16 -> 7.5.21


## [2.5.0] - (2026.7.12)

### Added
 - RTSP cameras can now be added through the plugin’s “Advanced Settings” section.
 
## [2.4.0] - (2026.7.4)

### Fixed
 - fixed the WBGT calculation
 
### Changed
 - Added additional supported product types for AirConditionerAccessory
 

## [2.3.0] - (2026.6.12)

### Added
 - Added an option to force communication over IPv4.
 - Added contact sensor state option for garage doors

### Changed
 - Updated the behavior so that sensitive data is not logged unless debugMode is enabled.


## [2.2.3] - (2026.5.8)

### Changed
 - Updated so that switch names are not sanitized when the plugin restarts.
This prevents the plugin from unnecessarily updating the name set by the user in the Home app.
Since information from the Home app is not sent to the plugin, I recommend changing device names through the plugin settings to avoid unintended name updates.
 - Fixed an issue where switch names were not being sanitized for devices that contain multiple switches.
This will suppress the Homebridge warning logs.

## [2.2.2] - (2026.4.8)

### Fixed
 - Fix an issue where the Configured Name was sometimes not applied

## [2.2.1] - (2026.3.9)

### Fixed
 - Homebridge V2: supported.
 - Accessory names containing invalid characters are now automatically sanitized to be HomeKit-compliant. This prevents the "invalid  'ConfiguredName'" warning and reduces the risk of accessories failing to be added or becoming unresponsive in the Home app.
 - Logging added to show when names are corrected.

## [2.2.0] - (2026.2.23)

### Fixed
 - Fixed the HeaterAccessory to follow the device’s schema information.
If you want to revert to the previous behavior, set the category code to qn_old. 

### Changed
 - Updated the handling of DP Codes so they are now processed in a case‑insensitive manner.
 - Updated the plugin settings window to mask the password field.

## [2.1.0] - (2026.1.5)

### Added
 - Support Towel Rack(mjj)
The implementation is almost identical to a thermostat.
The difference is that there is no limit on the set temperature.
The lower limit, upper limit, and step of the set temperature may sometimes differ from expectations. Since this is an issue with the product you are using, please override it to any desired value in Advanced Options.

## [2.0.3] - (2025.9.6)

First release after forking.
Homebridge verified.

### Added
 - Added an illuminance sensor to the IRControlHub.
 - Added an accessory that displays weather temperature and humidity.
 - config.schema.json to allow customizing the Service information for each accessory.

### Fixed
 - Fixed an issue where learned infrared codes in the IRControlHub would not work in some cases. This likely improves compatibility with older devices.
### Changed
 - Updated the IRControlHub to calculate WBGT based on its temperature and humidity readings and expose it as an accessory.
 - Updated the Outlet accessory so that its “in use” status can be checked in the Home app.

## [1.7.0] - (unreleased)

### Added
- Add scene support. (#118)
- Add Wireless Switch support (`wxkg`).
- Add Solar Light support (`tyndj`).
- Add Dehumidifier support (`cs`).
- Add Scene Switch support (`wxkg`).
- Add device overriding config support. "Non-standard DP" devices have possibility to be supported now. (#119)
- Add Camera support (`sp`). Thanks @ErrorErrorError for the contribution
- Add Air Conditioner support (`kt`). (#160)
- Add Air Conditioner Controller support (`ktkzq`). (#160)
- Add Diffuser support (`xxj`). (#175)
- Add Temperature Control Socket support (`wkcz`).
- Add Environmental Detector support (`hjjcy`).
- Add Water Valve Controller support (`sfkzq`).
- Add IR Remote Control support (`infrared_tv`, `infrared_stb`, `infrared_box`, `infrared_ac`, `infrared_fan`, `infrared_light`, `infrared_amplifier`, `infrared_projector`, `infrared_waterheater`, `infrared_airpurifier`). (#191)
- Add IR AC Controller support (`hwktwkq`).
- Add Fingerbot support (`szjqr`).
- Add Smart Lock support (`ms`, `jtmspro`). (#120) Thanks @pfgimutao for the contribution
- Add Alarm Host support (`mal`). (#246) Thanks @bFollon for the contribution
- Add Vibration Sensor support (`zd`). (#262)
- Add adaptive lighting support. (#272)
- Add Wireless Doorbell support (`wxml`). (#277)
- Add IR Remote Control support (`wsdykq`).
- Add Layout to display schema in sections. (#283) Thanks @donavanbecker for the contribution
- Add option to make accessory and unbridged accessory (#285) Thanks @donavanbecker for the contribution
- Add inching button for switches.
- Add support to 2ch windows covering. (#339) Thanks @CryptoIR for the contribution
- Add retry when network error happened.
- Add Pet Feeder support (`cwwsq`). (#483) Thanks @aselekoglu for the contribution


### Fixed
- Fix `RotationSpeed` missing one level. (#170)
- Fix `bright_value` not sent for the `C/CW` lights who doesn't have `work_mode`. (#171)
- Fix crash when camera sends an invalid status message.
- Fix incorrect Door and Window Controller state. (#178)
- Fix Thermostat cold mode not working (#242).
- Order temp before get the min and max for IRAirConditionerAccessory. (#433) Thanks @tuliocll for the contribution
- Fix energy usage not updated after homebridge restart. (#268)


### Changed
- Support Ceiling Fan icon customize and Floor Fan `lock`, `swing` feature. (#131)
- Adjust humidity range of dehumidifier and humidifier.
- Print scene id in logs.
- Update support for RGB Power Switch (`dj`).
- Support showing device online status via `StatusActive`. (#172)
- Update unit and range of `RotationSpeed`, need clean accessory cache to take effect. (#174, #273)
- Support Diffuser RGB light. (#184)
- Support Fan light temperature and color. (#184)
- Support Humidifier light. (#184)
- Expose energy usage for outlets/switches. (#190) Thanks @lstrojny for the contribution
- Strict config validate for `deviceOverrides`. (#278)
- Support AirPurifier air quality.
- Throw `HapStatusError` when device is offline.


## [1.6.0] - (2022.12.3)

This version has been completely rewritten in TypeScript, brings a lot of bug fix and new device support.

### New Accessories
- Add CO Detector support (`cobj`).
- Add CO2 Detector support (`co2bj`).
- Add Water Detector support (`sj`).
- Add Temperature and Humidity Sensor support (`wsdcg`, `wnykq`). Thanks @bimusiek for the contribution
- Add Light Sensor support (`ldcg`).
- Add Motion Sensor support (`pir`).
- Add PM2.5 Detector support (`pm25`).
- Add Door and Window Controller support (`mc`).
- Add Curtain Switch support (`clkg`). (#8)
- Add Human Presence Sensor support (`hps`). (#17)
- Add Thermostat support (`wk`). (#19) Thanks @burcadoruciprian for the contribution
- Add Spotlight support (`sxd`). (#21)
- Add Irrigator support (`ggq`). (#28)
- Add Scene Light Socket support (`qjdcz`). (#33)
- Add Ceiling Fan Light support (`fsd`). (#37)
- Add Thermostat Valve support (`wkf`). (#50)
- Add Motion Sensor Light support (`gyd`). (#65)
- Add Multiple Dimmer and Dimmer Switch support (`tgq`, `tgkg`). (#82)
- Add Humidifier support (`jsq`). (#89) Thanks @akaminsky-net for the contribution


### Added
- Add config validation during plugin initialization.
- Add instruction message for handling API errors.
- Add debounce in `BaseAccessory.sendCommands()` for better API request peformance.
- Persist `TuyaDeviceList.{uid}.json` for debugging. (#41)
- Add `homeWhitelist` option for whitelisting homes. (#84) Thanks @JulianLepinski for the contribution


### Fixed
- Fix 1004 signature error when url query has more than 2 elements.
- Fix 1010 token expired error when refresh access_token.
- Fix 1106 permission error when polling device info list.
- Fix 1100, 2017 errors when login. (via config validation)
- Fix Lightbulb `RGBW` and `RGBCW` work mode not switched properly (#12 #56 #59)
- Fix Lightbulb color temperature not working. (#13)
- Fix Thermostat temperature units handling. (#20)
- Fix Thermostat mode handling. (#26)
- Fix Curtain Switch with no position feature. (#27)
- Fallback when receiving MQTT message with wrong order. (#35)
- Fix wrong temperature on sensor. (#38)
- Fix fan speed issue. (#46 #51)
- Workaround for Thermostat with wrong schema property (#74)
- Fix Contact Sensor not working (#75)
- Fix iOS 16 default accessory name issue. (#85)


### Changed
- Rewritten in TypeScript, brings benefits of type checking, smart code hints, etc.
- Reimplement accessory logics. More friendly for accessory developers.
- Update device info list polling logic. Less API errors.
- Now `Manufactor`, `Serial Number` and `Model` will be correctly displayed in HomeKit.
- All devices will be shown in HomeKit by default (Including unsupported device).
- Updated unit test.
- Updated documentations. Thanks @prabch for the contribution


### Removed
- Remove `debug` option. Silence logs for users. For debugging, please refer to [troubleshooting](https://github.com/homebridge-plugins/homebridge-tuya#troubleshooting).
- Remove `lang` option.
- Remove `username` and `password` options for `Custom` project. User will be created and authorized automatically. (#11)
